import { streamText, createTextStreamResponse } from 'ai'
import { gateway } from '@ai-sdk/gateway'
// import { googleGenAI } from '@ai-sdk/google-genai'
import { anthropic } from '@ai-sdk/anthropic'
import { google } from '@ai-sdk/google'
import { generateText } from 'ai'

export default defineEventHandler(async (event:any) => {
    // const config = useRuntimeConfig()
  const { prompt, mode, language } = await readBody(event)
  if (!prompt) {
    throw createError({ statusCode: 400, message: 'Prompt is required' })
  }

console.log('API called')

  const body = await readBody(event)

  console.log('Payload:', body)

  const config = useRuntimeConfig()
  console.log("Runtime config -------------> ", config)

  console.log(
    'API key exists ------------->:',
    !config.anthropicApiKey
  )

  let instructions: string
  let maxOutputTokens: number
  const model1 = gateway('anthropic/claude-haiku-4.5')
  // const modelGoogleAIStudio =  google('gemini-2.5-flash-lite')

  const modelGoogleAIStudio = google(
    'gemini-2.5-flash',
    {
      apiKey: config.googleApiKey
    }
  )

  const modelAnthropic = anthropic('claude-sonnet-4-5')
    // const model1 = anthropic('claude-sonnet-4-5', {
    //     apiKey: config.anthropicApiKey
    // })
// Using gateway with a lightweight model (good for translation, often cheaper)
  const model = gateway('anthropic/claude-haiku-4.5') // or 'google/gemini-2.5-flash-lite' etc.

//   const model = gateway('anthropic/claude-haiku-4.5')
//   const modelGemini = googleGenAI('gemini-3-pro-preview')
  const preserveMarkdown = 'IMPORTANT: Preserve all markdown formatting (bold, italic, links, etc.) exactly as in the original.'

  switch (mode) {
    case 'fix':
      instructions = `You are a writing assistant. Fix all spelling and grammar errors in the given text. ${preserveMarkdown} Only output the corrected text, nothing else.`
      maxOutputTokens = 500
      break
    case 'extend':
      instructions = `You are a writing assistant. Extend the given text with more details, examples, and explanations while maintaining the same style. ${preserveMarkdown} Only output the extended text, nothing else.`
      maxOutputTokens = 500
      break
    case 'reduce':
      instructions = `You are a writing assistant. Make the given text more concise by removing unnecessary words while keeping the meaning. ${preserveMarkdown} Only output the reduced text, nothing else.`
      maxOutputTokens = 300
      break
    case 'simplify':
      instructions = `You are a writing assistant. Simplify the given text to make it easier to understand, using simpler words and shorter sentences. ${preserveMarkdown} Only output the simplified text, nothing else.`
      maxOutputTokens = 400
      break
    case 'summarize':
      instructions = 'You are a writing assistant. Summarize the given text concisely while keeping the key points. Only output the summary, nothing else.'
      maxOutputTokens = 200
      break
    case 'translate':
      instructions = `You are a writing assistant. Translate the given text to ${language || 'English'}. ${preserveMarkdown} Only output the translated text, nothing else.`
      maxOutputTokens = 500
      break
    case 'continue':
    default:
      instructions = `You are a writing assistant providing inline autocompletions.
CRITICAL RULES:
- Output ONLY the NEW text that comes AFTER the user's input
- NEVER repeat any words from the end of the user's text
- Keep completions short (1 sentence max)
- Match the tone and style of the existing text
- ${preserveMarkdown}`
      maxOutputTokens = 25
      break
  }

  const result = streamText({
    model: model,
    // model: googleGenAI('claude-haiku-4.5'),
    instructions,
    prompt,
    maxOutputTokens
  })

  return createTextStreamResponse({ stream: result.textStream })
})
